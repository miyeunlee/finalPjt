package org.mohajo.studyrepublic.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;

//임시 테이블
/**
 * @author	이미연
 * @since	2019. 1. 22.
 * @version	
 * - 기능 설명 1
 */
@Data
@Entity
public class Member {
	   @Id 
	   private String id;

	   @Column(nullable = false)
	   private String password;
	   
	   @Column(nullable = false)
	   private String name;
	   
	   @Column(nullable = false)
	   private String gender;
	   
	/*   @Temporal(TemporalType.DATE)*/   // 년, 월, 일 형식으로 출력하겠다. DATE를 TIMESTAMP로 바꾸면 시, 분, 초 까지 출력.
	   @Column(nullable = false)
	   private String birth;   // 파라미터를 @ModelAttribute로 한번에 받기 위함. birth를 Date로 적으면 에러남.... DB상에는 DATE로 저장함.
	   /*private Date birth;   */                                                    
	   
	   @Column(nullable = false)
	   private String nickname;
	   
	   @Column(nullable = false)
	   private String email;
	   
	   @Column(nullable = false)
	   private String phonenumber;
	   
	   @Column(nullable = false)
	   private int visibility;
	   
	   @Column(nullable = false)
	   private String profile_origin_name;
	   
	   @Column(nullable = false)
	   private String profile_save_name;
	   
	   @Temporal(TemporalType.DATE)   // 년, 월, 일 형식으로 출력하겠다. DATE를 TIMESTAMP로 바꾸면 시, 분, 초 까지 출력.
	   @Column(nullable = false)
	   private Date registration_date = new Date();   // 자동으로 현재 날짜로 가입일을 초기화.
	/*   private java.sql.Date date2 = new java.sql.Date(visibility, visibility, visibility);*/
	   
	   @ManyToOne
	   @JoinColumn(name = "MEMBER_STATUS_CODE")
	   private MemberStatusCD memberStatusCD = new MemberStatusCD("N");
	   
	   @ManyToOne
	   @JoinColumn(name = "GRADE_CODE")
	   private GradeCD gradeCD = new GradeCD("N");
}
