//
//import java.io.Serializable;
//
//import javax.persistence.Embeddable;
//import javax.persistence.JoinColumn;
//
//import org.mohajo.studyrepublic.domain.Member;
//import org.mohajo.studyrepublic.domain.Study;
//
///**
// * @author	이미연
// * @since	2019. 1. 22.
// * @version	
// * - 기능 설명 1
// */
//@Embeddable
//public class StudyMemberId implements Serializable {
//
////	@Id
////	org.springframework.beans.factory.BeanCreationException: Error creating bean with name 'entityManagerFactory' defined in class path resource [org/springframework/boot/autoconfigure/orm/jpa/HibernateJpaConfiguration.class]: Invocation of init method failed; nested exception is org.hibernate.AnnotationException: org.mohajo.studyrepublic.domain.id.StudyMemberId must not have @Id properties when used as an @EmbeddedId
//	@JoinColumn(name = "study_id")
//	private Study studyId;
//	
////	@Id
//	@JoinColumn(name = "id")
//	private Member member;
//	
//}
