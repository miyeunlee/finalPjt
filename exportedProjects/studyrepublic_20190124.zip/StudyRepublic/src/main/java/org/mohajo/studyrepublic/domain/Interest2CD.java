package org.mohajo.studyrepublic.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

//임시테이블
/**
 * @author	이미연
 * @since	2019. 1. 22.
 * @version	
 * - 기능 설명 1
 */
@Data
@Entity
@Table(name = "interest_2_cd", schema = "StudyRepublic")
public class Interest2CD {
	
	@Id
	@Column(name="interest_2_code")
	private String interest2Code;
	
	private String codeValueEnglish;
	private String codeValueKorean;

}
